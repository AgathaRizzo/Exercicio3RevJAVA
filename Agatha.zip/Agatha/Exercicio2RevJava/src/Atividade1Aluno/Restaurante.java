package Atividade1Aluno;

public class Restaurante {
    double cardapio;
    
}
