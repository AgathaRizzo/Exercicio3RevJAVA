package Atividade1Aluno;

public class Mesa {
    
}
